import React from 'react'

export default function NotFound() {
  return (
    <div>
        <h1>This Page Is Note Founds</h1>
    </div>
  )
}
